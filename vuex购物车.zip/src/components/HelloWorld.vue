<template>
  <div class="hello">
    <h1>Vuex购物车demo</h1>
    <p>商品信息</p>
    <!-- 商品页 -->
    <el-table :data="this.$store.state.tableData" style="width: 100%">
      <!-- <el-table-column size="medium" type="selection" width="55"></el-table-column> -->
      <el-table-column label="id" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.date }}</span>
        </template>
      </el-table-column>
      <el-table-column label="名称" width="120">
        <template slot-scope="scope">
          <p>{{ scope.row.name }}</p>
        </template>
      </el-table-column>
      <el-table-column label="价格" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.price }}</span>
        </template>
      </el-table-column>
      <el-table-column label="数量" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px" v-show="scope.row.num>=1">{{ scope.row.num }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button v-show="!scope.row.num>=1" type="primary" @click="add(scope.row)">加入购物车</el-button>
          <div v-show="scope.row.num>=1">
            <el-button size="mini" type="primary" @click="handleDelete(scope.row)">+</el-button>
            <el-button size="mini" type="warning" @click="handleEdit(scope.row)">-</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <hr />
    <!--  -->
    <div style="margin-top: 20px">
      <!-- <el-button @click="toggleSelection(tableData)">反选</el-button> -->
      <!-- <el-button @click="toggleSelection()">全不选</el-button> -->
      <!-- <el-button @click="toggleSelection1(tableData)">全选</el-button> -->
    </div>
    <!--购物车-->
    <el-table
      :data="this.$store.state.list"
      @select="onTableSelect"
      @selection-change="handleSelectionChange"
      style="width: 100%"
      ref="multipleTable"
    >
      <el-table-column label="id" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.date }}</span>
        </template>
      </el-table-column>
      <el-table-column label="名称" width="120">
        <template slot-scope="scope">
          <p>{{ scope.row.name }}</p>
        </template>
      </el-table-column>
      <el-table-column label="价格" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.price }}</span>
        </template>
      </el-table-column>

      <el-table-column type="selection" width="120" l></el-table-column>

      <el-table-column label="数量" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.num }}</span>
        </template>
      </el-table-column>
      <el-table-column label="总价" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.price*scope.row.num }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <div>
            <el-button size="mini" type="primary" @click="jia(scope.row)">+</el-button>
            <el-button size="mini" type="warning" @click="jian(scope.$index, scope.row)">-</el-button>
            <el-button size="mini" type="danger" @click="del1(scope.$index, scope.row)">x</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!--  -->
    <div class="div">
      <p>
        <span>总数:{{num1()}}</span>
        <span>总价:{{num2()}}</span>
      </p>
      <el-button type="danger" @click="del">清空购物车</el-button>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "HelloWorld",
  data() {
    return {
      multipleSelection: [],
      done1: true
    };
  },
  computed: {
    tableData() {
      return this.$store.state.list;
    }
  },
  methods: {
    //单选
    onTableSelect(rows, row) {
      let selected = rows.length && rows.indexOf(row) !== -1;
      row.done = selected;
    },
    //全选
    handleSelectionChange(rows){
      
      if (rows.length > 0) {
        rows.forEach(v=>{
          v.done=true
        })
      }else{
        this.tableData.forEach(v=>{
          v.done=false
        })
      }
      console.log(rows)
      console.log(this.tableData)
    },
    //减
    handleEdit(row) {
      this.$store.commit("handleEdit", row);
    },
    // 总数量
    num1() {
      var n = 0;
      this.$store.state.list.forEach(v => {
        if (v.done) {
          n += v.num;
        }
      });
      return n;
    },
    //总价
    num2() {
      var n = 0;
      this.$store.state.list.forEach(v => {
        if (v.done) {
          n += v.num * v.price;
        }
      });
      return n;
    },
    //加
    handleDelete(row) {
      this.$store.commit("handleDelete", row);
    },
    //加入购物车
    add(row) {
      this.$store.commit("add", row);
    },
    //购物车的减
    jian(index, row) {
      this.$store.commit("jian", { index: index, row: row });
    },
    //购物车的加
    jia(row) {
      this.$store.commit("jia", row);
    },
    //清空购物车
    del() {
      this.$store.commit("del");
    },
    //购物车的单行删除
    del1(index, row) {
      this.$store.commit("del1", { index: index, row: row });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.hello {
  width: 1000px;
  height: 400px;
  /* border: 1px solid ; */
  margin: 0 auto;
}
td{
  padding: 0;
  text-align: center;
}
h1,p{
  margin: 0;
  padding: 0;
}
.div {
  display: flex;
  justify-content: space-between;
}
</style>
