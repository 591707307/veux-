/**
 * index.js Created by SmallFour on 2019/9/28/9:07
 */
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  // 状态管理对象
  state: {
    tableData: [
      {
        date: '1',
        name: '鱼香肉丝',
        price: '12',
        num: 0,
        done: false
      },
      {
        date: '2',
        name: '宫保鸡丁',
        price: '14',
        num: 0,
        done: false
      },
      {
        date: '3',
        name: '土豆丝',
        price: '10',
        num: 0,
        done: false
      },
      {
        date: '4',
        name: '米饭',
        price: '2',
        num: 0,
        done: false
      }
    ],
    list: [],
    num: 0,
    price: 0
  },
  // mutations
  mutations: {
    // 减
    handleEdit (state, row) {
      row.num--
      if (row.num < 1) {
        state.list.forEach((v, i) => {
          if (row.date === v.date) {
            state.list.splice(i, 1)
          }
        })
      }
    },
    // 加
    handleDelete (state, row) {
      row.num += 1
    },
    // 加入购物车
    add (state, row) {
      row.num = 1
      row.done = false
      state.list.push(row)
    },
    // 购物车的减
    jian (state, data) {
      data.row.num--
      if (data.row.num < 1) {
        state.list.splice(data.index, 1)
      }
    },
    // 购物车的加
    jia (state, row) {
      row.num++
    },
    // 清空购物车
    del (state) {
      state.tableData.forEach(element => {
        element.num = 0
      })
      state.list.splice(0, state.list.length)
    },
    // 单行删除
    del1 (state, data) {
      data.row.num = 0
      state.list.splice(data.index, 1)
    }
  }
})

export default store
