<template>
  <div class="wrapper">
    123
    <li v-html="list.content"></li>
  </div>
</template>
<script>
import axios from "axios";
export default {
  data() {
    return {
      list: {}
    };
  },
  computed: {
    num() {
      return this.store.state.count;
    }
  },
  methods: {
    getDate() {
      let n = this.$route.params.id;
      console.log(n);
      axios.get(`https://www.vue-js.com/api/v1/topic/${n}`).then(d => {
        console.log(d.data.data);
        this.list = d.data.data
        // console.log();
      });
    },
    renderList(value) {
      this.getDate();
    }
  },
  created() {
    // this.getDate();
    let n = this.$route.params.id;
    // console.log(n);
    axios.get(`https://www.vue-js.com/api/v1/topics/${n}`).then(d => {
      console.log(d);
      this.list = d
      // console.log();
    });
  },
  beforeMount() {
    this.getDate();
  }
};
</script>
<style scoped>
</style>